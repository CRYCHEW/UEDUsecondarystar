-- Supabase schema for 优教育中学星星奖励计划
-- Run once in Supabase SQL Editor. All balance changes are recorded in star_ledger.

create extension if not exists pgcrypto;

create table if not exists public.teacher_allowlist (
  email text primary key check (email = lower(email)),
  display_name text not null,
  role text not null check (role in ('admin','teacher')),
  subjects text[] not null default '{}'
);

insert into public.teacher_allowlist(email, display_name, role, subjects) values
 ('mcchew93@gmail.com','Ms Crystal','admin',array['BM','BI','BMK']),
 ('pennyparis1106@gmail.com','Ms Penny','teacher',array['SEJ','CHE','EKO']),
 ('missyip1028@gmail.com','Ms Yip','teacher',array['BI','BIO']),
 ('yilingtan1011@gmail.com','Ms Tan','teacher',array['BM','ACC','AM']),
 ('carmenleeee220@gmail.com','Ms Carmen','teacher',array['EKO','BIO','BI']),
 ('return.dao@gmail.com','Mr Thomas','teacher',array['AM','PHY','ASK']),
 ('khookk517@gmail.com','Mr Khoo','teacher',array['SEJ','GEO','RBT']),
 ('cherrylow7902@gmail.com','Ms Hui','teacher',array['MM','SC']),
 ('leowmeiyan0111@gmail.com','Ms Leow','teacher',array['MM','SC','BC']),
 ('yapchloe520@gmail.com','Ms Chloe','teacher',array['SEJ']),
 ('huiqi1026370@gmail.com','棋老师','teacher',array['GEO']),
 ('chanhayley64@gmail.com','曾老师','teacher',array['BM','BMK']),
 ('ngyiqi20@gmail.com','吴老师','teacher',array['SEJ']),
 ('ubilyss@gmail.com','谢老师','teacher',array['MM']),
 ('hyean3289@gmail.com','马老师','teacher',array['MM','SC','CHE'])
on conflict (email) do update set display_name=excluded.display_name, role=excluded.role, subjects=excluded.subjects;

create sequence if not exists public.student_number_seq start 1;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check(role in ('student','teacher','admin')),
  full_name text not null,
  grade text,
  phone text,
  student_number text unique,
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.teacher_accounts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  display_name text not null,
  role text not null check(role in ('teacher','admin')),
  subjects text[] not null default '{}'
);

create or replace function public.provision_auth_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare t public.teacher_allowlist%rowtype; n text; g text;
begin
  if new.email is not null then
    select * into t from public.teacher_allowlist where email = lower(new.email);
    if not found then raise exception 'This email is not on the teacher allowlist'; end if;
    insert into public.profiles(id, role, full_name, approved)
      values(new.id, t.role, t.display_name, true);
    insert into public.teacher_accounts(user_id,email,display_name,role,subjects)
      values(new.id,lower(new.email),t.display_name,t.role,t.subjects);
  elsif new.phone is not null then
    n := nullif(trim(new.raw_user_meta_data->>'full_name'),'');
    g := nullif(trim(new.raw_user_meta_data->>'grade'),'');
    if n is null or g is null then raise exception 'Student name and grade are required'; end if;
    insert into public.profiles(id, role, full_name, grade, phone, student_number, approved)
      values(new.id, 'student', n, g, new.phone,
        'YOU-' || to_char(now() at time zone 'Asia/Kuala_Lumpur','YY') || '-' || lpad(nextval('public.student_number_seq')::text,6,'0'), false);
  else
    raise exception 'Use an approved teacher email or verified student phone';
  end if;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.provision_auth_user();

create table if not exists public.star_requests (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id),
  student_name text not null,
  subject text not null,
  teacher_id uuid not null references public.teacher_accounts(user_id),
  reason text not null,
  details text not null,
  requested_stars integer not null check(requested_stars between 1 and 100),
  approved_stars integer check(approved_stars between 0 and 100),
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.star_ledger (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id),
  amount integer not null,
  reason text not null,
  source text not null,
  source_id uuid,
  created_at timestamptz not null default now(),
  unique(source, source_id)
);

create table if not exists public.daily_checkins (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id),
  local_date date not null,
  created_at timestamptz not null default now(),
  unique(student_id, local_date)
);

create or replace function public.current_role()
returns text language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = (select auth.uid())
$$;

create or replace function public.check_in_today()
returns void language plpgsql security definer set search_path = '' as $$
declare d date := (now() at time zone 'Asia/Kuala_Lumpur')::date;
begin
  if (select auth.uid()) is null or public.current_role() <> 'student' then raise exception 'Student login required'; end if;
  if d < date '2027-01-02' or d > date '2027-12-28' then raise exception 'The reward period is closed'; end if;
  if extract(isodow from d) > 5 then raise exception 'Check-in is available Monday to Friday only'; end if;
  insert into public.daily_checkins(student_id, local_date) values((select auth.uid()), d);
  insert into public.star_ledger(student_id, amount, reason, source, source_id)
    select (select auth.uid()), 1, '每日签到', 'checkin', id from public.daily_checkins
    where student_id=(select auth.uid()) and local_date=d;
exception when unique_violation then raise exception 'You have already checked in today';
end; $$;

create or replace function public.submit_star_request(p_subject text, p_teacher_id uuid, p_reason text, p_details text, p_stars integer)
returns uuid language plpgsql security definer set search_path = '' as $$
declare rid uuid; nm text;
begin
  if (select auth.uid()) is null or public.current_role() <> 'student' then raise exception 'Student login required'; end if;
  if not exists(select 1 from public.profiles where id=(select auth.uid()) and approved) then raise exception 'Student account is awaiting teacher approval'; end if;
  if not exists(select 1 from public.teacher_accounts where user_id=p_teacher_id and p_subject=any(subjects)) then raise exception 'Selected teacher does not teach this subject'; end if;
  select full_name into nm from public.profiles where id=(select auth.uid());
  insert into public.star_requests(student_id,student_name,subject,teacher_id,reason,details,requested_stars)
    values((select auth.uid()),nm,p_subject,p_teacher_id,p_reason,p_details,p_stars) returning id into rid;
  return rid;
end; $$;

create or replace function public.review_star_request(p_request_id uuid, p_approve boolean, p_stars integer default null)
returns void language plpgsql security definer set search_path = '' as $$
declare r public.star_requests%rowtype; role_now text;
begin
  role_now := public.current_role();
  if role_now not in ('teacher','admin') then raise exception 'Teacher login required'; end if;
  select * into r from public.star_requests where id=p_request_id and status='pending' for update;
  if not found then raise exception 'Request is no longer pending'; end if;
  if role_now <> 'admin' and r.teacher_id <> (select auth.uid()) then raise exception 'You can only review requests assigned to you'; end if;
  if p_approve then
    if p_stars is null or p_stars < 0 or p_stars > 100 then raise exception 'Approved star amount is invalid'; end if;
    update public.star_requests set status='approved', approved_stars=p_stars, reviewed_at=now() where id=r.id;
    if p_stars > 0 then insert into public.star_ledger(student_id,amount,reason,source,source_id)
      values(r.student_id,p_stars,r.reason,'request',r.id); end if;
  else
    update public.star_requests set status='rejected', approved_stars=0, reviewed_at=now() where id=r.id;
  end if;
end; $$;

create or replace function public.approve_student(p_student_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if public.current_role() <> 'admin' then raise exception 'Admin login required'; end if;
  update public.profiles set approved=true where id=p_student_id and role='student';
end; $$;

alter table public.teacher_allowlist enable row level security;
alter table public.profiles enable row level security;
alter table public.teacher_accounts enable row level security;
alter table public.star_requests enable row level security;
alter table public.star_ledger enable row level security;
alter table public.daily_checkins enable row level security;

drop policy if exists profiles_read_self_admin on public.profiles;
create policy profiles_read_self_admin on public.profiles for select to authenticated
  using(id=(select auth.uid()) or public.current_role()='admin');
drop policy if exists teacher_directory_read on public.teacher_accounts;
create policy teacher_directory_read on public.teacher_accounts for select to authenticated using(true);
drop policy if exists requests_read_authorized on public.star_requests;
create policy requests_read_authorized on public.star_requests for select to authenticated
  using(student_id=(select auth.uid()) or public.current_role()='admin' or teacher_id=(select auth.uid()));
drop policy if exists ledger_read_owner_admin on public.star_ledger;
create policy ledger_read_owner_admin on public.star_ledger for select to authenticated
  using(student_id=(select auth.uid()) or public.current_role()='admin');
drop policy if exists checkins_read_owner_admin on public.daily_checkins;
create policy checkins_read_owner_admin on public.daily_checkins for select to authenticated
  using(student_id=(select auth.uid()) or public.current_role()='admin');

revoke all on public.teacher_allowlist from anon, authenticated;
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant select on public.teacher_accounts to authenticated;
grant select on public.star_requests to authenticated;
grant select on public.star_ledger, public.daily_checkins to authenticated;
revoke all on function public.provision_auth_user() from public, anon, authenticated;
revoke all on function public.check_in_today() from public, anon;
revoke all on function public.submit_star_request(text,uuid,text,text,integer) from public, anon;
revoke all on function public.review_star_request(uuid,boolean,integer) from public, anon;
revoke all on function public.approve_student(uuid) from public, anon;
grant execute on function public.check_in_today() to authenticated;
grant execute on function public.submit_star_request(text,uuid,text,text,integer) to authenticated;
grant execute on function public.review_star_request(uuid,boolean,integer) to authenticated;
grant execute on function public.approve_student(uuid) to authenticated;
